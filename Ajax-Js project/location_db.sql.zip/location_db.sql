-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 27, 2024 at 07:55 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `location_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE `cities` (
  `id` int(11) NOT NULL,
  `city_name` varchar(255) NOT NULL,
  `country_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`id`, `city_name`, `country_id`) VALUES
(1, 'Delhi', 1),
(2, 'Mumbai', 1),
(3, 'Bengaluru', 1),
(4, 'Chennai', 1),
(5, 'Dhaka', 2),
(6, 'Barisal', 2),
(7, 'Khulna', 2),
(8, 'Chattogram', 2),
(9, 'Tokyo', 3),
(10, 'Osaka', 3),
(11, 'Kyoto', 3),
(12, 'Hiroshima', 3),
(13, 'Sydney', 4),
(14, 'Melbourne', 4),
(15, 'Brisbane', 4),
(16, 'Perth', 4);

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `id` int(11) NOT NULL,
  `country_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `country_name`) VALUES
(1, 'India'),
(2, 'Bangladesh'),
(3, 'Japan'),
(4, 'Australia');

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

CREATE TABLE `locations` (
  `id` int(11) NOT NULL,
  `location_name` varchar(255) NOT NULL,
  `city_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `locations`
--

INSERT INTO `locations` (`id`, `location_name`, `city_id`) VALUES
(1, 'Connaught Place', 1),
(2, 'Chandni Chowk', 1),
(3, 'Dwarka', 1),
(4, 'Noida', 1),
(5, 'Juhu Beach', 2),
(6, 'Colaba', 2),
(7, 'Bandra', 2),
(8, 'Worli', 2),
(9, 'Shibuya', 3),
(10, 'Shinjuku', 3),
(11, 'Harajuku', 3),
(12, 'Akihabara', 3),
(13, 'Bondi', 4),
(14, 'Manly', 4),
(15, 'Surry Hills', 4),
(16, 'Darling Harbour', 4),
(17, 'Uttara', 5),
(18, 'Mirpur', 5),
(19, 'Mogbazar', 5),
(20, 'Dhanmondi', 5),
(21, 'Sagardi', 6),
(22, 'Bandh Road', 6),
(23, 'Cox Road', 6),
(24, 'Nobogram', 6),
(25, 'Sonadanga', 7),
(26, 'Gollamari', 7),
(27, 'Rupsha', 7),
(28, 'Khalishpur', 7),
(29, 'Agrabad', 8),
(30, 'Pahartali', 8),
(31, 'Patenga', 8),
(32, 'Chawk Bazar', 8),
(33, 'Shinjuku', 9),
(34, 'Shibuya', 9),
(35, 'Akihabara', 9),
(36, 'Roppongi', 9),
(37, 'Namba', 10),
(38, 'Umeda', 10),
(39, 'Tennoji', 10),
(40, 'Shin-Osaka', 10),
(41, 'Gion', 11),
(42, 'Arashiyama', 11),
(43, 'Fushimi', 11),
(44, 'Higashiyama', 11),
(45, 'Naka-ku', 12),
(46, 'Minami-ku', 12),
(47, 'Asaminami-ku', 12),
(48, 'Higashi-ku', 12),
(49, 'Bondi Beach', 13),
(50, 'Manly', 13),
(51, 'Parramatta', 13),
(52, 'Darling Harbour', 13),
(53, 'CBD', 14),
(54, 'St Kilda', 14),
(55, 'Fitzroy', 14),
(56, 'Southbank', 14),
(57, 'Fortitude Valley', 15),
(58, 'South Brisbane', 15),
(59, 'New Farm', 15),
(60, 'Kangaroo Point', 15),
(61, 'Fremantle', 16),
(62, 'Cottesloe', 16),
(63, 'Scarborough', 16),
(64, 'Subiaco', 16);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`id`),
  ADD KEY `country_id` (`country_id`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `locations`
--
ALTER TABLE `locations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `city_id` (`city_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cities`
--
ALTER TABLE `cities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `locations`
--
ALTER TABLE `locations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cities`
--
ALTER TABLE `cities`
  ADD CONSTRAINT `cities_ibfk_1` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`);

--
-- Constraints for table `locations`
--
ALTER TABLE `locations`
  ADD CONSTRAINT `locations_ibfk_1` FOREIGN KEY (`city_id`) REFERENCES `cities` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
